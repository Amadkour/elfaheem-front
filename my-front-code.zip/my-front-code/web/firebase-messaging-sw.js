// web/firebase-messaging-sw.js
//
// Required for Firebase Cloud Messaging to work on the web platform.
// Must live at exactly this path: web/firebase-messaging-sw.js
// (Firebase's JS SDK looks for it there by default — do not rename or move it.)
//
// Notes:
//   - Web Push only works over HTTPS or http://localhost. It will silently
//     fail on plain HTTP hosting.
//   - The config below matches web/firebase_options.dart (DefaultFirebaseOptions.web).
//     If you ever rotate/regenerate Firebase config, update both places together.

importScripts("https://www.gstatic.com/firebasejs/10.13.0/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/10.13.0/firebase-messaging-compat.js");

firebase.initializeApp({
  apiKey: "AIzaSyAAMGDzpS1mT9jK524CdDPzAOy5GrnwQ00",
  appId: "1:520907928286:web:18b6dc8a8c5f9f5b77884f",
  messagingSenderId: "520907928286",
  projectId: "elfaheem",
  storageBucket: "elfaheem.firebasestorage.app",
});

const messaging = firebase.messaging();

// Handles messages that arrive while the site/tab is NOT focused (or closed).
// Foreground messages (tab open & focused) are instead handled in Dart via
// FirebaseMessaging.onMessage in notification_service.dart.
//
// To view these logs: open DevTools → Application tab → Service Workers,
// or DevTools → Console with "Show messages from other contexts" enabled —
// a background/inactive tab's default console view will NOT show them.
messaging.onBackgroundMessage((payload) => {
  console.log("[FCM][background]", {
    title: payload.notification?.title,
    body: payload.notification?.body,
    data: payload.data,
  });

  const title = payload.notification?.title || "ElFaheem";
  const body = payload.notification?.body || "";

  self.registration.showNotification(title, {
    body,
    icon: "/icons/Icon-192.png", // adjust path if your web icons live elsewhere
  });
});